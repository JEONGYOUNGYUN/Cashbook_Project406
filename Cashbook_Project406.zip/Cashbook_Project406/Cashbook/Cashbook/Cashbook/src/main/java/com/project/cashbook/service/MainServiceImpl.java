package com.project.cashbook.service;

public class MainServiceImpl implements MainService {

}
