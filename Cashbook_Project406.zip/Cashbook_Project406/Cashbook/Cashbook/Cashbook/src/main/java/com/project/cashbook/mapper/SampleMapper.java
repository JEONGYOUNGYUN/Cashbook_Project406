package com.project.cashbook.mapper;

public interface SampleMapper {

}
